<?php

 

$servername = "gator4194";
$username = "ezsupply_manager";
$password = "odgx6!YxP[MW";
$dbname = "ezsupply_ez_supply_manager";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
 


?>