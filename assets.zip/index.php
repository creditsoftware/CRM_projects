<?php

header("Location:https://ezsupplymanager.com/home");

?>