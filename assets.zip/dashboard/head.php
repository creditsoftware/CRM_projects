 <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
    <title>User Dashboard | EzSupplyManager</title>
    
	<link rel="icon" href="../icon.png" type="image/x-icon" />
	
    <!--  BEGIN CUSTOM STYLE FILE  -->
    <link href="plugins/tagInput/tags-input.css" rel="stylesheet" type="text/css" />
    <!--  END CUSTOM STYLE FILE  -->
	 
	<!--Get your own code at fontawesome.com-->
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
    <link href="assets/css/loader.css" rel="stylesheet" type="text/css" />
    <script src="assets/js/loader.js"></script>

    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/plugins.css" rel="stylesheet" type="text/css" />
    <!-- END GLOBAL MANDATORY STYLES -->

    <!-- BEGIN PAGE LEVEL PLUGINS/CUSTOM STYLES -->
    <link href="plugins/apex/apexcharts.css" rel="stylesheet" type="text/css">
 <link href="assets/css/dashboard/dash_1.css" rel="stylesheet" type="text/css" />
    <!-- END PAGE LEVEL PLUGINS/CUSTOM STYLES -->
 
 <link href="assets/css/dashboard/dash_2.css" rel="stylesheet" type="text/css" />
 
 
    <link rel="stylesheet" type="text/css" href="assets/css/widgets/modules-widgets.css">   
    <!-- END PAGE LEVEL PLUGINS/CUSTOM STYLES -->
<script src="assests/sweetalert.min.js"></script>
  <!--  BEGIN CUSTOM STYLE FILE  -->
    <link href="assets/css/elements/tooltip.css" rel="stylesheet" type="text/css" />
    <!--  END CUSTOM STYLE FILE  -->
 <script src='assests/a076d05399.js'></script>
 <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>