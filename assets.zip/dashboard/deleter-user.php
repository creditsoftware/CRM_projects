<?php
include "gets_user.php";

include '../connection.php';
  
  $user = $_GET['user'];

    	   
    
	    $sql = "update registered_users
		 set
		 is_dell	= 'yes'
		 where 
		  user_id='$user'
		 ";

  if ($conn->query($sql) === TRUE) {

 
  header("Location:update-users");
 
  }
    
 

?>